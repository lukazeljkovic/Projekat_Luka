﻿using System;

namespace InstagramServices
{
    public class Class1
    {
    }
}

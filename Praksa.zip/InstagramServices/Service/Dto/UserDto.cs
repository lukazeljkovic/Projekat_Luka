﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Repository.Models
{
    public class UserDto
    {
        public int Id { get; set; }

        public string Username { get; set; }

    }
}
